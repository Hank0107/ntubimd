from django.shortcuts import render
from .models import NewsData

def news_list(request):
    news = NewsData.objects.all()
    return render(request, 'news/news_list.html', {'news': news})

from .models import NewsData

def news_list(request):
    # 從資料庫中獲取所有新聞資料
    news = NewsData.objects.all()
    # 將新聞資料傳遞到模板中進行顯示
    return render(request, 'news/news_list.html', {'news': news})