from django.shortcuts import render, get_object_or_404, redirect
from .models import Stock

def introduce(request):
    return render(request, 'introduce.html')

def stock_list(request):
    stock_list = Stock.objects.all().order_by('-date', 'stock_code')[:155]
    return render(request, 'stock_list.html', {'stock_list': stock_list})

def stock_detail(request, stock_code):
    stock = Stock.objects.filter(stock_code=stock_code).first()
    return render(request, 'stock_detail.html', {'stock': stock})
