from django.contrib import admin
from .models import News

admin.site.register(News)

from .models import NewsData

admin.site.register(NewsData)